(function() {
  window.app || (window.app = {});

}).call(this);
