(function() {
  window.app || (window.app = {});

}).call(this);
(function() {
  app.App = (function() {
    function App() {
      console.log("app working");
    }

    return App;

  })();

}).call(this);
(function() {
  $(function() {
    return console.log("im working!!!!");
  });

}).call(this);
